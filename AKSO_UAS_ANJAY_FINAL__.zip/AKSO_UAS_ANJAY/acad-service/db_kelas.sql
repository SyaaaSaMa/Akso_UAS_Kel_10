CREATE TABLE mahasiswa (
    nim VARCHAR(10) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    jurusan VARCHAR(50),
    angkatan INT
);

CREATE TABLE mata_kuliah (
    kode_mk VARCHAR(10) PRIMARY KEY,
    nama_mk VARCHAR(100) NOT NULL,
    sks INT NOT NULL
);

CREATE TABLE krs (
    id_krs BIGSERIAL PRIMARY KEY,
    nim VARCHAR(10),
    kode_mk VARCHAR(10),
    nilai CHAR(2),
    semester INT,
    FOREIGN KEY (nim) REFERENCES mahasiswa(nim),
    FOREIGN KEY (kode_mk) REFERENCES mata_kuliah(kode_mk)
);

CREATE TABLE bobot_nilai (
    nilai CHAR(2) PRIMARY KEY,
    bobot FLOAT
);

INSERT INTO mahasiswa (nim, nama, jurusan, angkatan) VALUES
('2503154242', 'Arrya Akbar Samudra Pasa', 'Sains Data', 2025),
('2503154023', 'Ghita Natsha Putri', 'Sains Data', 2025);

INSERT INTO mata_kuliah (kode_mk, nama_mk, sks) VALUES
('IF101', 'Pemrograman Dasar', 3),
('IF102', 'Basis Data', 3),
('IF103', 'Aljabar Matriks', 3);

INSERT INTO krs (nim, kode_mk, nilai, semester) VALUES
('2503154242', 'IF101', 'A', 1),
('2503154242', 'IF102', 'B+', 1),
('2503154242', 'IF103', 'B', 1),

('2503154023', 'IF101', 'A', 1),
('2503154023', 'IF102', 'A', 1),
('2503154023', 'IF103', 'B+', 1);

INSERT INTO bobot_nilai (nilai, bobot) VALUES
('A', 4.0),
('A-', 3.75),
('B+', 3.5),
('B', 3.0),
('B-', 2.75),
('C+', 2.5),
('C', 2.0),
('D', 1.0),
('E', 0.0);