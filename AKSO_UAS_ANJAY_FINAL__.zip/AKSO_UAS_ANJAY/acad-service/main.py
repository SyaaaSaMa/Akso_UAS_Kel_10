from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import os
import psycopg2
from psycopg2.extras import RealDictCursor

DB_HOST = os.getenv("DB_HOST", "acad-db")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "products")
DB_USER = os.getenv("DB_USER", "productuser")
DB_PASSWORD = os.getenv("DB_PASSWORD", "productpass")

def get_db_connection():
    """
    Membuat koneksi baru ke PostgreSQL dan mengembalikan cursor dict.
    Dipanggil di setiap request dan ditutup setelah selesai.
    """
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        cursor_factory=RealDictCursor,
    )
    return conn

class Mahasiswa(BaseModel):
    nim: str
    nama: str
    jurusan: Optional[str] = None
    angkatan: Optional[int] = None

class IPSResult(BaseModel):
    nim: str
    nama: str
    jurusan: Optional[str] = None
    total_nilai: float
    total_sks: int
    ips: float


# ==============================
# Inisialisasi FastAPI
# ==============================

app = FastAPI(
    title="Acad Service",
    version="1.0.0",
    description="Service Akademik sederhana (wajib + opsional) dengan perhitungan IPS.",
)

# supaya aman kalau diakses dari mana saja
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
\

# ==============================
# FUNGSI BACA FILE UI
# ==============================

def read_ui_file() -> str:
    """
    Membaca file frontend/ui.html yang ada di dalam container acad-service
    (satu folder dengan main.py, tapi di subfolder 'frontend').
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(base_dir, "frontend", "ui.html")  # <── PENTING: pakai frontend/ui.html
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return "<h1>ui.html tidak ditemukan di dalam container acad-service.</h1>"


# ==============================
# ROUTE UI  ->  http://localhost:3002/ui
# ==============================

@app.get("/ui", response_class=HTMLResponse, include_in_schema=False)
async def serve_ui():
    html = read_ui_file()
    return HTMLResponse(content=html, status_code=200)


# ==============================
# HEALTH CHECK
# ==============================

@app.get("/health")
async def health_check():
    return {
        "status": "Acad Service is running",
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


# ==============================
# ENDPOINT MAHASISWA
# ==============================

@app.get("/api/acad/mahasiswa", response_model=List[Mahasiswa])
async def list_mahasiswa():
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT nim, nama, jurusan, angkatan
                FROM mahasiswa
                ORDER BY nim;
                """
            )
            rows = cur.fetchall()
            return rows
    finally:
        conn.close()


@app.get("/api/acad/mahasiswa/{nim}", response_model=Mahasiswa)
async def get_mahasiswa(nim: str):
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT nim, nama, jurusan, angkatan
                FROM mahasiswa
                WHERE nim = %s;
                """,
                (nim,),
            )
            row = cur.fetchone()

            if not row:
                raise HTTPException(status_code=404, detail="Mahasiswa tidak ditemukan")

            return row
    finally:
        conn.close()


# ==============================
# ENDPOINT IPS
# ==============================

@app.get("/api/acad/ips/{nim}", response_model=IPSResult)
async def hitung_ips(nim: str):
    """
    total_nilai = Σ (bobot * sks)
    total_sks   = Σ sks
    IPS         = total_nilai / total_sks
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # cek mahasiswa
            cur.execute(
                """
                SELECT nim, nama, jurusan
                FROM mahasiswa
                WHERE nim = %s;
                """,
                (nim,),
            )
            mhs = cur.fetchone()
            if not mhs:
                raise HTTPException(status_code=404, detail="Mahasiswa tidak ditemukan")

            # ambil data KRS + SKS + bobot
            cur.execute(
                """
                SELECT
                    k.nilai,
                    mk.sks,
                    b.bobot
                FROM krs k
                JOIN mata_kuliah mk ON k.kode_mk = mk.kode_mk
                JOIN bobot_nilai  b ON k.nilai = b.nilai
                WHERE k.nim = %s;
                """,
                (nim,),
            )
            rows = cur.fetchall()

            if not rows:
                return IPSResult(
                    nim=mhs["nim"],
                    nama=mhs["nama"],
                    jurusan=mhs.get("jurusan"),
                    total_nilai=0.0,
                    total_sks=0,
                    ips=0.0,
                )

            total_nilai = 0.0
            total_sks = 0
            for r in rows:
                sks = int(r["sks"])
                bobot = float(r["bobot"])
                total_sks += sks
                total_nilai += bobot * sks

            ips = total_nilai / total_sks if total_sks > 0 else 0.0

            return IPSResult(
                nim=mhs["nim"],
                nama=mhs["nama"],
                jurusan=mhs.get("jurusan"),
                total_nilai=round(total_nilai, 2),
                total_sks=total_sks,
                ips=round(ips, 2),
            )
    finally:
        conn.close()
